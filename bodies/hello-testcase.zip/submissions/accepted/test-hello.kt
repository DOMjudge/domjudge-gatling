/*
 * This should give CORRECT on the default problem 'hello'.
 *
 * @EXPECTED_RESULTS@: CORRECT
 */

fun main(args : Array<String>) {
	println("Hello world!");
}
