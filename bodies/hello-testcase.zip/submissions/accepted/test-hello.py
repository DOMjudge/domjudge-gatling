# This should give CORRECT on the default problem 'hello'.
#
# Note that by default the extension .py is (currently) associated to
#Python2. The code below should also work with Python3, though.
#
# @EXPECTED_RESULTS@: CORRECT

print("Hello world!")
