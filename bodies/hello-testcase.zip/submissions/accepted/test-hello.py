# This should give CORRECT on the default problem 'hello'.
#
# Note that by default the extension .py is associated to Python2. If
# alternatively .py is associated to Python3, then this will result in
# COMPILER-ERROR.
#
# @EXPECTED_RESULTS@: CORRECT

print "Hello world!"
